/* 
⚠ Warning! ⚠
Jangan di ganti cr ini bos
© danz-xyz
api free : hookrest.my.id
owner : 62895323195263 [ Danz ]
*/

import chalk from "chalk";
import { watchFile, unwatchFile } from "fs";
import { fileURLToPath } from "url";
import moment from "moment-timezone";

// ————————————————————————————————
// ==== id ch ====
global.idch = ["120363287205109562@newsletter"];
// ===== CONFIG =====
global.owner = ["6285939763314"];

global.info = {
    nomorbot: "6285143098461",
    latin: "ファクレジー",  
    nomorowner: "6285939763314",
    namaowner: "ғᴀᴄʜʀᴇᴢʏ ||"
}
global.namabot = "フライジー";
global.namaowner = "ファクレジー";
global.googleAiApiKey = "AIzaSyCHZlp5sscm406vJ4DJG_eoGHGvmTHre_w";
// ===== THUMBNAIL =====
global.thum = "https://files.catbox.moe/m44n7d.jpg";

// ==== audio ===
global.audio = "https://raw.githubusercontent.com/Faazd232/dat1/main/uploads/184848-1766378723420.opus";

// ===== OPTIONS =====
global.autoread = true; // OPSIONAL
global.stage = {
    wait: "*[ sʏsᴛᴇᴍ ] sᴇᴅᴀɴɢ ᴅɪᴘʀᴏsᴇs...*",
    error: "*[ ᴡᴀʀɴɪɴɢ ] ᴘʀᴏsᴇs ɢᴀɢᴀʟ!*"
}

// ===== LINK ====
global.lgh = ""; // Github
global.lwa = "https://wa.me/6285939763314"; // Whatsapp
global.lig = ""; // Instagram
global.lgc = ""; // Group Chat Whatsapp
global.lch = ""; // Channels Whatsapp 
let file = fileURLToPath(import.meta.url);
watchFile(file, async () => {
    unwatchFile(file);
    console.log(`${chalk.white.bold(" [SISTEM]")} ${chalk.green.bold(`FILE DIUPDATE "settings.js"`)}`);
    import(`${file}?update=${Date.now()}`);
});

import fs from "fs"
import path from "path"
import archiver from "archiver"
import axios from "axios"
import crypto from "crypto"
import { fileTypeFromBuffer } from "file-type"
import moment from "moment-timezone"
import { fileURLToPath } from "url"

const __dirname = path.dirname(fileURLToPath(import.meta.url))

// ===== CONFIG =====
const githubToken = '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'
const owner = 'Faazd232'
const branch = 'main'
let repos = ['dat1','dat2','dat3','dat4']

async function ensureRepoExists(repo) {
    try {
        await axios.get(`https://api.github.com/repos/${owner}/${repo}`, {
            headers: { Authorization: `Bearer ${githubToken}` }
        })
    } catch (e) {
        if (e.response?.status === 404) {
            await axios.post(`https://api.github.com/user/repos`,
                { name: repo, private: false },
                { headers: { Authorization: `Bearer ${githubToken}` } }
            )
            if (!repos.includes(repo)) repos.push(repo)
        } else throw e
    }
}

function generateRepoName() {
    return `dat-${crypto.randomBytes(3).toString('hex')}`
}

async function uploadToGitHub(buffer) {
    const detected = await fileTypeFromBuffer(buffer)
    const ext = detected?.ext || 'bin'
    const code = crypto.randomBytes(3).toString('hex')
    const fileName = `${code}-${Date.now()}.${ext}`
    const filePathGitHub = `uploads/${fileName}`

    const base64Content = Buffer.from(buffer).toString('base64')
    let targetRepo = repos[Math.floor(Math.random()*repos.length)]
    try { await ensureRepoExists(targetRepo) }
    catch { targetRepo = generateRepoName(); await ensureRepoExists(targetRepo) }

    await axios.put(
        `https://api.github.com/repos/${owner}/${targetRepo}/contents/${filePathGitHub}`,
        { message:`Upload file ${fileName}`, content:base64Content, branch },
        { headers:{ Authorization:`Bearer ${githubToken}` } }
    )

    return `https://raw.githubusercontent.com/${owner}/${targetRepo}/${branch}/${filePathGitHub}`
}

// ===== BACKUP BOT =====
async function backupBot(conn) {
    try {
        const backupFileName = `backup-${moment().format("YYYY-MM-DD")}.zip`
        const outputPath = path.join(__dirname, "..", backupFileName)

        const output = fs.createWriteStream(outputPath)
        const archive = archiver("zip", { zlib: { level: 9 } })
        archive.pipe(output)

        archive.glob("**/*", {
            cwd: path.join(__dirname, ".."),
            ignore: [
                "*.zip",
                "node_modules/**",
                "session/**",
                "sessions/**",
                "database.json",
                "package-lock.json"
            ]
        })

        await archive.finalize()
        await new Promise(resolve => output.on("close", resolve))

        const buffer = fs.readFileSync(outputPath)
        const url = await uploadToGitHub(buffer)

        // Kirim URL ke owner
        const ownerNumber = "6285939763314"
        const ownerJid = ownerNumber + "@s.whatsapp.net"
        await conn.sendMessage(ownerJid, { text: `✅ Backup otomatis berhasil\n\nURL: ${url}` })

        fs.unlinkSync(outputPath)
        console.log("✅ Backup selesai dan URL dikirim ke owner")
    } catch (e) {
        console.error("Auto backup error:", e.message)
    }
}

// ===== AUTO BACKUP MALAM =====
export default function autoBackup(conn) {
   /* setInterval(() => {
        const now = moment().tz("Asia/Jakarta")
        const hour = now.hour()
        const minute = now.minute()

        // Jam 00:00
        if (hour === 0 && minute === 0) {*/
            console.log("[AUTO BACKUP] Memulai backup malam hari")
            backupBot(conn)
  /*     }
    }, 60 * 1000) // cek tiap 1 menit*/
}

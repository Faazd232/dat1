import fs from 'fs'
import fetch from 'node-fetch'
import moment from 'moment-timezone'

const DB_PATH = './database/idautoshalat.json'
const sentCache = {} // anti dobel per hari

async function fetchJson(url) {
  const res = await fetch(url)
  if (!res.ok) throw new Error(`HTTP ${res.status}`)
  return res.json()
}

export default function autoshalat(conn) {
  console.log('[AUTO SHALAT] Service dimulai...')

  setInterval(async () => {
    try {
      if (!fs.existsSync(DB_PATH)) return

      const db = JSON.parse(fs.readFileSync(DB_PATH))
      const now = moment().tz('Asia/Makassar').format('HH:mm')
      const today = moment().tz('Asia/Makassar').format('YYYY-MM-DD')

      console.log(`[AUTO SHALAT] Cek waktu: ${now}`)

      for (const groupId of Object.keys(db)) {
        const cfg = db[groupId]
        if (!cfg.enabled) continue

        const api = `https://cloudku.us.kg/api/murotal/jadwal?id=${cfg.cityId}&time=${today}`
        const data = await fetchJson(api)

        const jadwal = data?.data?.jadwal
if (!jadwal) continue

const waktuShalat = {
  Subuh: jadwal.subuh,
  Dzuhur: jadwal.dzuhur,
  Ashar: jadwal.ashar,
  Maghrib: jadwal.maghrib,
  Isya: jadwal.isya
}

        for (const [nama, waktu] of Object.entries(waktuShalat)) {
          const key = `${groupId}-${nama}-${today}`

          console.log(
            `[AUTO SHALAT] ${cfg.cityName} | ${nama} ${waktu} | now ${now}`
          )

          if (waktu === now && !sentCache[key]) {
            sentCache[key] = true

            console.log(
              `[AUTO SHALAT] KIRIM → ${nama} ke ${groupId}`
            )

            await conn.sendMessage(groupId, {
              text:
`🕌 *Waktu Shalat ${nama}*

⏰ ${waktu} WIT
📍 ${cfg.cityName}

Semoga Allah menerima ibadah kita 🤲`
            })
          }
        }
      }
    } catch (e) {
      console.error('[AUTO SHALAT ERROR]', e.message)
    }
  }, 60 * 1000) // CEK TIAP 1 MENIT
}
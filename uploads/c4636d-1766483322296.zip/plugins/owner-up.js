import fs from 'fs'
import path from 'path'

let handler = async (m, { text, usedPrefix }) => {
    try {
        if (!text) return m.reply(`⚠️ Masukkan nama file plugin yang ingin diupdate\nContoh: ${usedPrefix}up hayam`)

        // Ambil kode dari reply
        let quotedText = m.quoted?.text || m.quoted?.message?.conversation
        if (!quotedText) return m.reply(`⚠️ Reply kode baru untuk plugin ${text}.js`)

        // Tentukan path file
        let filePath = path.join('./plugins', text.endsWith('.js') ? text : text + '.js')

        // Cek file ada atau nggak
        if (!fs.existsSync(filePath)) return m.reply(`❌ File ${filePath} tidak ditemukan!`)

        // Update file
        fs.writeFileSync(filePath, quotedText)

        m.reply(`✅ File berhasil diupdate: ${path.basename(filePath)}`)

    } catch (e) {
        console.error(e)
        m.reply(`❌ Terjadi error saat update file:\n${e.message}`)
    }
}

handler.help = ['updateplugin <nama file>']
handler.tags = ['owner']
handler.command = /^(up)$/i
handler.owner = true

export default handler
import axios from 'axios'

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) return m.reply(`ᴋɪʀɪᴍ ᴅᴇɴɢᴀɴ ᴛᴇᴋs ʏᴀɴɢ ɪɴɢɪɴ ᴅɪ ᴛʀᴀɴsʟᴀᴛᴇ ᴋᴇ ʙᴀʜᴀsᴀ ɪɴᴅᴏɴᴇsɪᴀ`)

    const url = args.join(' ') 
    
    await m.reply('sᴇᴅᴀɴɢ ᴍᴇɴɢᴀʀᴛɪᴋᴀɴ...')

    try {
        const { data } = await axios.get(`https://api.elrayyxml.web.id/api/tools/translate?text=${encodeURIComponent(url)}&lang=id`)

        if (!data?.status) {
        return m.reply('Error Jirr') 
        }
        if (!data?.result) {
        return m.reply('Resultnya gak ada jir') 
        }

        const res = data.result

        const gilax = `
Translate : ${url}
Hasil : ${res}`.trim()

        await conn.sendMessage(m.chat, {
            text: gilax
        }, { quoted: m })

    } catch (e) {
        console.log(e)
        m.reply('Errorrrrrrrrr')
    }
}

handler.help = ['translate <teks>']
handler.tags = ['tools']
handler.command = /^(trans|translate|translet)$/i
handler.limit = true

export default handler
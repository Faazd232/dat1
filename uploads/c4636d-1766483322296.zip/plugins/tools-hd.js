/*
 • Fitur By Anomaki Team
 • Created : xyzan code
 • Upscaler (Case)
 • Jangan Hapus Wm
 • https://whatsapp.com/channel/0029Vaio4dYC1FuGr5kxfy2l
 
 Scrape by : https://whatsapp.com/channel/0029Vap84RE8KMqfYnd0V41A/3513
*/
import axios from 'axios'
import fs from 'fs'


let handler = async (m, { conn, usedPrefix, command }) => {
    try
    {
        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || '';
        if (!mime) return m.reply(`Kirim atau balas gambar dengan caption ${usedPrefix + command}`);

        if (!mime.startsWith('image')) return m.reply(`Hanya mendukung gambar!`);

        await conn.sendMessage(m.chat,
        {
            react:
            {
                text: "🔄",
                key: m.key
            }
        });

        const media = await q.download();
        const tmp = `/tmp/${Date.now()}.jpg`;
        fs.writeFileSync(tmp, media);

        const img = fs.readFileSync(tmp).toString('base64');
        const create = await axios.post('https://aienhancer.ai/api/v1/r/image-enhance/create',
        {
            model: 3,
            image: `data:image/jpeg;base64,${img}`,
            settings: 'kRpBbpnRCD2nL2RxnnuoMo7MBc0zHndTDkWMl9aW+Gw='
        },
        {
            headers:
            {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10)',
                'Content-Type': 'application/json',
                origin: 'https://aienhancer.ai',
                referer: 'https://aienhancer.ai/ai-image-upscaler'
            }
        });

        const id = create.data.data.id;

        const result = await axios.post('https://aienhancer.ai/api/v1/r/image-enhance/result',
        {
            task_id: id
        },
        {
            headers:
            {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10)',
                'Content-Type': 'application/json',
                origin: 'https://aienhancer.ai',
                referer: 'https://aienhancer.ai/ai-image-upscaler'
            }
        });

        const output = result.data.data.output;

        fs.unlinkSync(tmp);

        const psn = `╰╼ ┈─ ⠁◌ ˚ IMAGE UPSCALE ⠹ !

• Task ID: ${id}
• Process: Success
• Result: HD Quality

     ׄ ֵ ━━━━━━━━━━━━━━━ ֵ ׄׄ
    ˚ 𓊆˒˓ ۫﹢ Request by ${m.pushName} ! ♡. . ⁺ ׅ`;

        await conn.sendMessage(m.chat,
        {
            image:
            {
                url: output
            },
            caption: psn
        },
        {
            quoted: m
        });

        await conn.sendMessage(m.chat,
        {
            react:
            {
                text: "✅",
                key: m.key
            }
        });

    }
    catch (e)
    {
        console.error(e);
        await conn.sendMessage(m.chat,
        {
            react:
            {
                text: "❌",
                key: m.key
            }
        });
        await m.errorReport(util.format(e), command);
    }
}

handler.tags = ["tools"]
handler.help = ["hd"]
handler.command = /^(hd|enhancer)$/i
export default handler
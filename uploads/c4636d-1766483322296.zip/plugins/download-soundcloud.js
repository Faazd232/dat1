import axios from 'axios'

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) return m.reply(`Mau Cari Apa? 🔍`)

const url = args[0]

    await m.reply('Sedang Mencari Lagu...')

    try {
        const { data } = await axios.get(`https://api.elrayyxml.web.id/api/downloader/soundcloud?url=${encodeURIComponent(url)}`)

const endpoin = `https://api.elrayyxml.web.id/api/downloader/soundcloud?url=${encodeURIComponent(url)}`

        if (!data?.status) {
        return m.reply('ᴀᴘɪ ᴇʀʀᴏʀ') 
        }
        if (!data?.result) {
        return m.reply(`Hasilnya Gak Ada Coba Cek Api Nya ${endpoin}`) 
        }
        const res = data.result

        const caption = `🎧 Sound Cloud Download
🔍 Query: ${url}\n\n
🎵 Title : ${res.title}
🎚️ Quality : ${res.quality}
📁 File Name : ${res.fileName}
🌐 Source : ${res.source}
⏳ Mohon Tunggu Lagunya Ya😏`

        await conn.sendMessage(
        m.chat, 
        { text: caption }, 
        { quoted: m } );
        
        await conn.sendMessage(
        m.chat, {
        audio: { url: res.downloadUrl }, 
        mimetype: 'audio/mpeg', 
        fileName: res.fileName, 
        }, 
        { quoted: m } );

    } catch (e) {
        console.error(e)
        m.reply('ɢᴀɢᴀʟ bang')
    }
}

handler.help = ['downloadsoundcloud <url>']
handler.tags = ['download']
handler.command = /^(downloadsoundcloud|dsc)$/i
handler.limit = true

export default handler
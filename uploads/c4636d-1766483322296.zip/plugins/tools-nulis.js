import axios from 'axios'

let handler = async (m, { conn, args }) => {
  if (!args.length) {
    return m.reply('✍️ Silahkan masukkan teks yang ingin ditulis')
  }

  const teks = args.join(' ')

  await m.reply('📝 Sedang menulis...')

  try {
    const res = await axios.get(
      `https://api.elrayyxml.web.id/api/maker/nulis?text=${encodeURIComponent(teks)}`,
      { responseType: 'arraybuffer' } // 🔥 PENTING
    )

    const buffer = Buffer.from(res.data)

    await conn.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: `✍️ *Hasil Nulis*\n\n"${teks}"`
      },
      { quoted: m }
    )

  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal membuat tulisan')
  }
}

handler.help = ['nulis <teks>']
handler.tags = ['tools']
handler.command = /^nulis$/i
handler.limit = true

export default handler
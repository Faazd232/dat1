import axios from 'axios'

let handler = async (m, { conn, args }) => {
  if (!args[0]) return m.reply(`Masukkan Teks Nya Anda Ingin Membuat Barcode Dengan Code Apa`) 

let textnya = args.join(' ') 

  await m.reply('🧠 Membuat Qr...')

  try {

    // 3. call unblur API
    const api = `https://api-faa.my.id/faa/qr-create?text=${encodeURIComponent(textnya)}`
    const { data } = await axios.get(api, { responseType: 'arraybuffer' }) 

    // 4. kirim hasil
    await conn.sendMessage(
      m.chat,
      {
      image: Buffer.from(data), 
      caption: 'Done Pak'
      },
      { quoted: m }
    )

  } catch (e) {
    console.error(e)
    m.reply('❌ Gak Bisa nya gagal')
  }
}

handler.command = ['createqr']
handler.tags = ['tools']
handler.help = ['CreateQr (text)']
handler.limit = true

export default handler
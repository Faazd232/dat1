export async function before(m, {
  conn,
  isBotAdmin,
  isAdmin
}) {
  try {
    if (!m.isGroup) return true
    if (m.fromMe) return true
    if (m.isBaileys) return true

    let chat = global.db.data.chats[m.chat]
    if (!chat?.antiTagSW) return true

    const isForwarded =
      m.mtype === 'groupStatusMentionMessage' ||
      m?.quoted?.mtype === 'groupStatusMentionMessage' ||
      m?.message?.groupStatusMentionMessage ||
      m?.message?.protocolMessage?.type === 25

    if (!isForwarded) return true


      await conn.sendMessage(m.chat, {
        text: `⚠️ Grup ini terdeteksi ditandai di Status WhatsApp oleh @${m.sender.split('@')[0]}, namun bot bukan admin.`,
        mentions: [m.sender]
      })
      return true
    

    if (isAdmin) return true

    // 🗑️ DELETE PESAN
    await conn.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        fromMe: false,
        id: m.key.id,
        participant: m.key.participant || m.sender
      }
    })

    // 🚪 KICK USER
    await conn.groupParticipantsUpdate(
      m.chat,
      [m.sender],
      'remove'
    )

    // 📢 NOTIFIKASI
    await conn.sendMessage(m.chat, {
      text: `🚫 @${m.sender.split("@")[0]} dikeluarkan karena menandai grup di Status WhatsApp.`,
      mentions: [m.sender]
    })

  } catch (e) {
    console.log('[ANTI TAG SW ERROR]', e)
  }

  return true
}
      


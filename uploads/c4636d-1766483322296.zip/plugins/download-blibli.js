import axios from 'axios'

const headers = {
  'User-Agent': 'Mozilla/5.0',
  'Accept': '*/*',
  'Origin': 'https://downloader.bhwa233.com',
  'Referer': 'https://downloader.bhwa233.com/'
}

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply('Masukkan link bilibili!')
  if (!/bilibili\.com|bilibili\.tv|b23\.tv/.test(text))
    return m.reply('Link tidak valid')

  await m.reply('⏳ Tunggu sebentar...')

  let { data } = await bilibiliDl(text)

  // MULTI PART
  if (data.isMultiPart) {
    await m.reply(`📦 Video memiliki *${data.pages.length}* part\n🎬 *${data.title}*`)

    for (let p of data.pages) {
      let caption = `*${data.title}*\nPart: ${p.page}`
      await conn.sendMessage(
        m.chat,
        {
          video: { url: p.downloadVideoUrl },
          caption
        },
        { quoted: m }
      )
    }

  // SINGLE VIDEO
  } else {
    let caption = `*BILI BILI DOWNLOADER*\n\n🎬 *${data.title}*`
    await conn.sendMessage(
      m.chat,
      {
        video: { url: data.downloadVideoUrl },
        caption
      },
      { quoted: m }
    )
  }
}

handler.command = /^(blibli|bbdl)$/i
handler.help = ['bilibili <url>']
handler.tags = ['download']
handler.limit = true

export default handler

// ================= SCRAPER =================
async function bilibiliDl(url) {
  const { data } = await axios.get(
    `https://downloader.bhwa233.com/v1/parse?url=${encodeURIComponent(url)}`,
    { headers }
  )

  if (data.data && !data.status) return data
  throw new Error('Gagal mengambil data video')
}
import axios from 'axios'
import FormData from 'form-data'

let handler = async (m, { conn, args }) => {
  if (!m.quoted)
    return m.reply('❌ Reply file .js')

  if (typeof m.quoted.download !== 'function')
    return m.reply('❌ Pesan yang direply bukan file')

  const mime = m.quoted.mimetype || ''
  if (!mime.includes('javascript'))
    return m.reply('❌ File harus JavaScript (.js)')

  const mode = args[0]
  if (!['cjs', 'esm'].includes(mode))
    return m.reply('❌ Mode: cjs / esm')

  // 1. download file dari WA
  const buffer = await m.quoted.download()

  // 2. buat form-data
  const form = new FormData()
  form.append('file', buffer, {
    filename: 'input.js',
    contentType: 'application/javascript'
  })
  form.append('mode', mode)

  // 3. kirim ke API
  const { data } = await axios.post(
    'https://api.elrayyxml.web.id/api/tools/codeconvert',
    form,
    { headers: form.getHeaders() }
  )

  if (!data.status)
    return m.reply('❌ Gagal convert')

  // 4. kirim hasil ke user
  await m.reply('```js\n' + data.result + '\n```')
}

handler.command = ['codeconvert']
handler.tags = ['owner']
handler.help = ['codeconvert cjs|esm']
handler.owner = true;

export default handler
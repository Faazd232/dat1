let handler = async (m, { conn }) => {
  if (!global.ttSearch || !global.ttSearch[m.sender])
    return m.reply('Tidak ada sesi pencarian')

  const data = global.ttSearch[m.sender]

  data.index++

  if (data.index >= data.results.length) {
    delete global.ttSearch[m.sender]
    return m.reply('✅ Sudah di hasil terakhir')
  }

  await kirimHasil(conn, m, m.sender)
}

handler.command = /^lanjut$/i

export default handler

async function kirimHasil(conn, m, sender) {
  const data = global.ttSearch[sender]
  const res = data.results[data.index]

  const caption = `
*TIKTOK SEARCH* (${data.index + 1}/${data.results.length})

Judul : ${res.title}
Dibuat : ${res.taken_at}
Negara : ${res.region}
Durasi : ${res.duration}
ID : ${res.id}
*INFO MUSIK*
Judul : ${res.music_info.title}
Artis : ${res.music_info.author}
Album : ${res.music_info.album}
Durasi : ${res.music_info.duration}
*STATUS VIDEO*
View : ${res.stats.views}
Likes : ${res.stats.likes}
Comment : ${res.stats.comment}
Share : ${res.stats.share}
Download : ${res.stats.download}
*AUTHOR VIDEO*
Nama : ${res.author.nickname}
Nama Lengkap : ${res.author.fullname}

Ketik *.lanjut* untuk video berikutnya
`.trim()

  await conn.sendMessage(
    m.chat,
    {
      video: { url: res.data },
      caption
    },
    { quoted: m }
  )
}
let handler = async (m, { conn }) => {
    let text = `Lapor Fryze Aktif`

    await conn.sendMessage(m.chat, {
        text,
        contextInfo: {
            mentionedJid: [m.sender],
            externalAdReply: {
                title: conn.user?.name || 'Bot Online',
                body: '~Fryzee',
                thumbnailUrl: global.thum || '',
                sourceUrl: global.lgc || '',
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m })
}

handler.customPrefix = /^(bot!)$/i
handler.command = new RegExp
handler.register = true

export default handler
let handler = async (m, { conn }) => {
  if (!global.ttTrend || !global.ttTrend[m.sender])
    return m.reply('Tidak ada sesi pencarian')

  const data = global.ttTrend[m.sender]

  data.index++

  if (data.index >= data.results.length) {
    delete global.ttTrend[m.sender]
    return m.reply('✅ Sudah di hasil terakhir')
  }

  await kirimHasilTt(conn, m, m.sender)
}

handler.command = /^next$/i

export default handler

async function kirimHasilTt(conn, m, sender) {
  const data = global.ttTrend[sender]
  const res = data.results[data.index]

  const caption = `
*TIKTOK SEARCH* (${data.index + 1}/${data.results.length})

Judul : ${res.title}
Dibuat : ${res.taken_at}
Negara : ${res.region}
Durasi : ${res.duration}
ID : ${res.id}
*INFO MUSIK*
Judul : ${res.music_info.title}
Artis : ${res.music_info.author}
Album : ${res.music_info.album}
Durasi : ${res.music_info.duration}
*STATUS VIDEO*
View : ${res.stats.views}
Likes : ${res.stats.likes}
Comment : ${res.stats.comment}
Share : ${res.stats.share}
Download : ${res.stats.download}
*AUTHOR VIDEO*
Nama : ${res.author.nickname}
Nama Lengkap : ${res.author.fullname}

Ketik *.next* untuk video berikutnya
`.trim()

  await conn.sendMessage(
    m.chat,
    {
      video: { url: res.data },
      caption
    },
    { quoted: m }
  )
}
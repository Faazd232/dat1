import axios from 'axios'
import { toPTT } from '../function/converter.js'

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) return m.reply(`Mau Cari Apa? 🔍`)

const url = args.join('') 

    await m.reply('Sedang Mencari Lagu...')

    try {
        const { data } = await axios.get(`https://api.elrayyxml.web.id/api/search/soundcloud?q=${encodeURIComponent(url)}`)

const endpoin = `https://api.elrayyxml.web.id`

        if (!data?.status) {
        return m.reply('ᴀᴘɪ sᴇᴀʀᴄʜ ᴇʀʀᴏʀ') 
        }
        if (!Array.isArray(data.result) || data.result.length === 0) {
        return m.reply(`Hasilnya Gak Ada Coba Cek Api Nya ${endpoin} [ search ]`) 
        }
        const res = data.result

       const link = res[0].url
       const { data: datax } = await axios.get(`https://api.elrayyxml.web.id/api/downloader/soundcloud?url=${encodeURIComponent(link)}`)
       
       if (!datax?.status) {
        return m.reply('ᴀᴘɪ ᴅᴏᴡɴʟᴏᴀᴅ ᴇʀʀᴏʀ') 
        }
        if (!datax?.result) {
        return m.reply(`Hasilnya Gak Ada Coba Cek Api Nya ${endpoin} [ download ]`) 
        }
        const ress = datax.result
        
        const audioBuffer = (await axios.get(ress.downloadUrl, { 
            responseType: 'arraybuffer',
            timeout: 60000 
        })).data

        // Konversi ke Opus + kirim sebagai voice note
        const { data: opusData } = await toPTT(audioBuffer, 'mp3')

        await conn.sendMessage(m.chat, {
            audio: opusData,
            mimetype: 'audio/ogg; codecs=opus',
            ptt: true,
            waveform: [0, 100, 0, 100, 0, 100, 0, 100],
            contextInfo: {
                externalAdReply: {
                    title: res[0].title.length > 30 ? res[0].title.slice(0, 27) + '...' : res[0].title,
                    body: res[0].author.name,
                    thumbnailUrl: res[0].thumbnail,
                    sourceUrl: res[0].url,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m })

    } catch (e) {
        console.error(e)
        m.reply('ɢᴀɢᴀʟ bang')
    }
}

handler.help = ['playsoundcloud']
handler.tags = ['play']
handler.command = /^(playsoundcloud|psc)$/i
handler.limit = true

export default handler
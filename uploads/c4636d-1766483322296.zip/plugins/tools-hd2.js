import axios from 'axios'

let handler = async (m, { conn, usedPrefix, command}) => {
	let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || q.mediaType || '';
    if (!mime) throw "Balas atau kirim pesan dengan caption  .ai-upscale"
        if (/^image/.test(mime) && !/webp/.test(mime)) {
        try { 
        await m.reply("Wait a minute")
        const media = await q.download()
        const result =  await upscaler(media)
        await conn.sendMessage(m.chat, { image: { url: result.output } ,caption: "Berhasil Upscale"}, { quoted: m })
        } catch (e) {
        throw `Terjadi kesalahan ${e.message}`
        }
        } else {
        return m.reply("Media tidak falid")
       }
   }
handler.command = /^(hd2|upscaler2)/i
handler.help = ["hd2"]
handler.tags = ["tools"]
handler.limit = true

export default handler

async function upscaler(path){
  try{
    const img = path.toString('base64')
    const create = await axios.post('https://aienhancer.ai/api/v1/r/image-enhance/create',
    {
    model: 3,
    image: `data:image/jpeg;base64,${img}`,
    settings: 'kRpBbpnRCD2nL2RxnnuoMo7MBc0zHndTDkWMl9aW+Gw='
   },
      {
 headers:{
 'User-Agent':'Mozilla/5.0 (Linux; Android 10)',
 'Content-Type':'application/json',
 origin:'https://aienhancer.ai',
 referer:'https://aienhancer.ai/ai-image-upscaler'
   }
  }
 )

    const id = create.data.data.id

    const result = await axios.post('https://aienhancer.ai/api/v1/r/image-enhance/result',
      { task_id: id },
      {
       headers:{
    'User-Agent':'Mozilla/5.0 (Linux; Android 10)',
    'Content-Type':'application/json',
    origin:'https://aienhancer.ai',
    referer:'https://aienhancer.ai/ai-image-upscaler'
   }
  }
 )
    const status = result.data.data.status
    if (status === 'succeeded') {
    return {
      id,
      output: result.data.data.output,
      input: result.data.data.input
    }
   } else if (status === 'failed') {
   throw new Error(result.data.data.error)
   }
     } catch(e){
    throw new Error ({ status:'engror', msg: e.message })
  }
}
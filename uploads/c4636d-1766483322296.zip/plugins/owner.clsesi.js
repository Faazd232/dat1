import fs from "fs";
let handler = async (m, { isCreator }) => {
const dirsesi = fs.readdirSync("./sessions").filter(e => e !== "creds.json")
for (const i of dirsesi) {
await fs.unlinkSync("./sessions/" + i)
}
m.reply(`*Berhasil membersihkan sampah ✅*
*${dirsesi.length}* sampah session file`)
}

handler.help = ["clearsession"];
handler.tags = ["owner"];
handler.command = ["boost", "clearsession", "clsesi", "clearsesi"]
handler.owner = true;

export default handler
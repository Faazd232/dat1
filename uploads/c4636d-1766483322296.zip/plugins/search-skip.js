let skip = async (m, { conn }) => {
  const session = global.ttFoto?.[m.sender]
  if (!session) return m.reply('Tidak ada foto aktif')

  session.index++

  if (session.index >= session.photos.length) {
    delete global.ttFoto[m.sender]
    return m.reply('Semua foto sudah dikirim')
  }

  await kirimFotoSekarang(conn, m, m.sender)
}

skip.command = /^(skip)$/i
export default skip

async function kirimFotoSekarang(conn, m, sender) {
  const session = global.ttFoto[sender]
  if (!session) return m.reply('Session foto habis')

  const { index, photos, meta } = session

  const caption = `
*TIKTOK PHOTO*
(${index + 1}/${photos.length})

Judul : ${meta.title}
Dibuat : ${meta.taken_at}
Negara : ${meta.region}
Durasi : ${meta.duration}
ID : ${meta.id}
*INFO MUSIK*
Judul : ${meta.music_info.title}
Artis : ${meta.music_info.author}
Album : ${meta.music_info.album}
Durasi : ${meta.music_info.duration}
*STATUS VIDEO*
View : ${meta.stats.views}
Likes : ${meta.stats.likes}
Comment : ${meta.stats.comment}
Share : ${meta.stats.share}
Download : ${meta.stats.download}
*AUTHOR VIDEO*
Nama : ${meta.author.nickname}
Nama Lengkap : ${meta.author.fullname}

Ketik *.skip* untuk foto berikutnya
`.trim()

  await conn.sendMessage(
    m.chat,
    {
      image: { url: photos[index] },
      caption
    },
    { quoted: m }
  )
}
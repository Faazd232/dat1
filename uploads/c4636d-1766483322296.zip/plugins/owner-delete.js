let handler = async (m, { conn }) => {
if (!m.quoted) throw false
let { chat, id } = m.quoted
 
conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender } })
            }
handler.tags = ["owner"]
handler.help = ["delete <reply>"]
handler.command = /^(delete|d|del)$/i
handler.owner = true

export default handler
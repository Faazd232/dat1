/**
 ╔══════════════════════
      ⧉  [edit] — [ai]
╚══════════════════════

  ✺ Type     : Plugin ESM
  ✺ Source   : https://whatsapp.com/channel/0029VbAXhS26WaKugBLx4E05
  ✺ Creator  : SXZnightmare
  ✺ Scrape      : 
  [ https://whatsapp.com/channel/0029Vb4jDY82ER6beeXLOp0k/1100 ]
  ✺ Scrape Maker : [ Alfi ]
  ✺ Note    : GG loh ya
*/

import { Buffer } from "buffer";

let handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        if (!text) {
            return m.reply(`*Contoh:* ${usedPrefix + command} ubah warna rambut jadi merah`);
        }

        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || "";

        if (!mime.startsWith("image/")) {
            return m.reply(`🍂 *Reply gambar yang ingin diedit.*`);
        }

        await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

        let buffer = await q.download();
        if (!buffer) {
            return m.reply(`🍂 *Gagal membaca gambar.*`);
        }

        let imageBase64 = Buffer.from(buffer).toString("base64");

        let payload = {
            image: imageBase64,
            prompt: text.trim()
        };

        let res = await fetch("https://ai-studio.anisaofc.my.id/api/edit-image", {
            method: "POST",
            headers: {
                "User-Agent": "Mozilla/5.0",
                "Accept": "*/*",
                "Content-Type": "application/json",
                "Origin": "https://ai-studio.anisaofc.my.id",
                "Referer": "https://ai-studio.anisaofc.my.id/"
            },
            body: JSON.stringify(payload)
        });

        let result;
        try {
            result = await res.json();
        } catch {
            return m.reply(`🍂 *Respon server tidak valid.*`);
        }

        if (!result || !result.imageUrl) {
            return m.reply(
                `🍂 *Gagal mengedit gambar.*\n` +
                `Server tidak mengembalikan hasil edit.`
            );
        }

        await conn.sendMessage(
            m.chat,
            {
                image: { url: result.imageUrl }
            },
            { quoted: m }
        );
    } catch {
        m.reply(`🍂 *Terjadi kesalahan saat memproses gambar.*`);
    } finally {
        await conn.sendMessage(m.chat, { react: { text: "", key: m.key } });
    }
};

handler.help = ["editimage <prompt>"];
handler.tags = ["ai"];
handler.command = /^(editimage)$/i;
handler.limit = true;
handler.register = false; // true kan jika ada fitur register atau daftar di bot mu.

export default handler;
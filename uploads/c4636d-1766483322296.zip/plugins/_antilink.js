const linkRegex = /https?:\/\/chat\.whatsapp\.com\/[0-9A-Za-z]{20,24}/i

export async function before(m, { conn, isAdmin, isBotAdmin }) {
  try {
    if (!m.isGroup) return true
    if (!m.text) return true
    if (m.fromMe) return true

    let chat = global.db.data.chats[m.chat]
    if (!chat || !chat.antilink) return true

    // Deteksi link
    if (!linkRegex.test(m.text)) return true

    // Admin kebal
    if (isAdmin) return true;

    // Link grup sendiri dibolehin
    if (isBotAdmin) {
      const gcLink = `https://chat.whatsapp.com/${await conn.groupInviteCode(m.chat)}`
      if (m.text.includes(gcLink)) return true
    }

    // Kirim peringatan
    
    // Hapus pesan

      await await conn.sendMessage(m.chat, {
  delete: {
    remoteJid: m.chat,
    fromMe: false,
    id: m.key.id,
    participant: m.key.participant || m.sender
  }
})
    


  } catch (e) {
    console.log('[ANTILINK ERROR]', e)
  }

  return true
}
    
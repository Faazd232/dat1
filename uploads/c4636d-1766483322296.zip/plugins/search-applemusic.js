import axios from 'axios'
import { toPTT } from '../function/converter.js'   // pastikan path bener

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) return m.reply(`Mau Cari Apa? 🔍`)

const url = args.join('') 

    await m.reply('Sedang Mencari Lagu...')

    try {
        const { data } = await axios.get(`https://api.elrayyxml.web.id/api/search/applemusic?q=${encodeURIComponent(url)}`)

const endpoin = `https://api.elrayyxml.web.id/api/search/applemusic?q=${encodeURIComponent(url)}`

        if (!data?.status) {
        return m.reply('ᴀᴘɪ ᴇʀʀᴏʀ') 
        }
        if (!Array.isArray(data.result) || data.result.length === 0) {
        return m.reply(`Hasilnya Gak Ada Coba Cek Api Nya ${endpoin}`) 
        }
        const res = data.result

        const caption = `🎧 Apple Music Search
🔍 Query: ${url}\n\n` + res.slice(0, 10).map((item, i) => { return `${i + 1}. ${item.title}
- Subtitle : ${item.subtitle}
- Link : ${item.link}
- Image : ${item.image}`; }).join("\n\n")

        await conn.sendMessage(
        m.chat, {
        image: { url: res[0].image }, 
        caption }, 
        { quoted: m } );

    } catch (e) {
        console.error(e)
        m.reply('ɢᴀɢᴀʟ bang')
    }
}

handler.help = ['searchapplemusic <musik>']
handler.tags = ['search']
handler.command = /^(searchapplemusic|sap)$/i
handler.limit = true

export default handler
let tes = async(m, { conn, text, usedPrefix, command }) => {
if (!text) return m.reply(`Dimana namanya?\nContoh: ${usedPrefix + command} Nano BotID`)
    await conn.updateProfileName(text)
    m.reply(`Success in changing the name of bot's number`)
    }
tes.tags = ["owner"]
tes.help = ["setnamabot <teks>"]
tes.command = /^(setnamabot|setbotname|setnamebot)$/i
tes.owner = true

export default tes
import axios from 'axios'

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) return m.reply(`ᴋɪʀɪᴍ ᴅᴇɴɢᴀɴ ɴᴀᴍᴀ ʏᴀɴɢ ɪɴɢɪɴ ᴅɪ ᴄᴀʀɪ ᴀʀᴛɪɴʏᴀ`)

    const url = args.join(' ') 
    
    await m.reply('sᴇᴅᴀɴɢ ᴍᴇɴᴄᴀʀɪ...')

    try {
        const { data } = await axios.get(`https://api-faa.my.id/faa/arti-nama?nama=${encodeURIComponent(url)}`)

const endpoin = `https://api-faa.my.id/faa/arti-nama?nama=${encodeURIComponent(url)}`
        if (!data?.status) {
        return m.reply('Error Jirr') 
        }
        if (!data?.arti) {
        return m.reply(`Artinya gak ada jir coba cek di ${endpoin}`) 
        }
const res = data.arti
let artinya = `Arti Nama ${url}
Artinya : ${res}`

       await conn.sendMessage(m.chat, {
       text: artinya, }, 
       { quoted: m })
        
       } catch (e) {
        console.error(e)
        m.reply('ɢᴀɢᴀʟ bang')
    }
}

handler.tags = ["tools"]
handler.help = ["artinama <nama>"]
handler.command = /^(artinama)$/i
handler.limit = true
export default handler
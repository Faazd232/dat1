let handler = async (m, { conn, args }) => {
  if (!args[0] || !args[1]) {
    return m.reply('*Choose:*\nsecond\nminute\nhour\nday\n\n*Example*\n10 second')
  }

  let time = parseInt(args[0])
  let unit = args[1].toLowerCase()
  let timer

  if (unit === 'second') timer = time * 1000
  else if (unit === 'minute') timer = time * 60000
  else if (unit === 'hour') timer = time * 3600000
  else if (unit === 'day') timer = time * 86400000
  else return m.reply('Unit waktu tidak valid')

  m.reply(`⏳ Open Time ${time} ${unit} dimulai dari sekarang`)

  setTimeout(async () => {
    await conn.groupSettingUpdate(m.chat, 'not_announcement')
    m.reply(`*⏰ ON TIME*\nGroup berhasil dibuka`)
  }, timer)
}

handler.tags = ['group']
handler.help = ['opentime <angka> <second|minute|hour|day>']
handler.command = /^(opentime|opent)$/i
handler.admin = true
handler.group = true

export default handler
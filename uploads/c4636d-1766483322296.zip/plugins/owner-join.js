const isUrl = (url) => {
    return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
}
let handler = async (m, { conn, args, text, usedPrefix, command }) => {
if (!text) return m.reply(`Contoh ${usedPrefix+command} linkgc`)
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return m.reply('Link Invalid!')
let result = args[0].split('https://chat.whatsapp.com/')[1]
await conn.groupAcceptInvite(result)
await m.reply(`*[ Done ]*`)
}
handler.tags = ["owner"]
handler.help = ["join <link>"]
handler.command = /^(join|masuk)/i
handler.owner = true
export default handler
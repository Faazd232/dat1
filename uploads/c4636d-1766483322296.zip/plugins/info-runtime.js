
import fs from "fs"

let handler = async (m, { conn, text, usedPrefix, command }) => {
    function runtime(seconds) {
  seconds = Number(seconds);
  const d = Math.floor(seconds / 86400);
  const h = Math.floor(seconds % 86400 / 3600);
  const m = Math.floor(seconds % 3600 / 60);
  const s = Math.floor(seconds % 60);

  return `${d ? d + " hari, " : ""}${h ? h + " jam, " : ""}${m ? m + " menit, " : ""}${s ? s + " detik" : ""}`;
}
await m.reply(`- *Runtime Bot :* ${runtime(process.uptime())}`) 
    console.l
}

handler.help = ["runtime"]
handler.tags = ["info"]
handler.command = /^runtime$/i

export default handler
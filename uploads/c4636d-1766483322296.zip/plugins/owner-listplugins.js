import fs from 'fs'
import path from 'path'

const pluginDir = './plugins'

let handler = async (m, { isOwner }) => {
  if (!isOwner) return m.reply('❌ Owner only')

  try {
    const files = fs.readdirSync(pluginDir).filter(f => f.endsWith('.js'))
    if (!files.length) return m.reply('⚠️ Tidak ada plugin di folder ./plugins')

    const list = files.map((file, i) => {
      const stats = fs.statSync(path.join(pluginDir, file))
      const size = (stats.size / 1024).toFixed(2) + ' KB'
      const modified = stats.mtime.toLocaleString()
      return `${i + 1}. ${file} | ${size} | ${modified}`
    }).join('\n')

    m.reply(`📂 Daftar Plugin:\n\n${list}`)
  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal membaca folder plugin')
  }
}

handler.customPrefix = /^(lp)$/i
handler.command = new RegExp
handler.tags = ['owner']
handler.help = ['listplugins']
handler.owner = true

export default handler
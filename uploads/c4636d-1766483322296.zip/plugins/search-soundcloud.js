import axios from 'axios'

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) return m.reply(`Mau Cari Apa? 🔍`)

const url = args.join('') 

    await m.reply('Sedang Mencari Lagu...')

    try {
        const { data } = await axios.get(`https://api.elrayyxml.web.id/api/search/soundcloud?q=${encodeURIComponent(url)}`)

const endpoin = `https://api.elrayyxml.web.id/api/search/soundcloud?q=${encodeURIComponent(url)}`

        if (!data?.status) {
        return m.reply('ᴀᴘɪ ᴇʀʀᴏʀ') 
        }
        if (!Array.isArray(data.result) || data.result.length === 0) {
        return m.reply(`Hasilnya Gak Ada Coba Cek Api Nya ${endpoin}`) 
        }
        const res = data.result

        const caption = `🎧 Sound Cloud Search
🔍 Query: ${url}\n\n` + res.slice(0, 5).map((item, i) => { return `${i + 1}. ${item.title}
👤 Arthist : ${item.author.name}
🔗 Url Arthist : ${item.author.url}
🆔 ID : ${item.id}
⏱ Duration : ${item.duration}
❤️ Likes : ${item.like_count}
▶️ Plays : ${item.play_count}
🔗 Url Sound : ${item.url}
🖼️ Image : ${item.thumbnail}`; }).join("\n\n")

        await conn.sendMessage(
        m.chat, {
        image: { url: res[0].thumbnail }, 
        caption }, 
        { quoted: m } );

    } catch (e) {
        console.error(e)
        m.reply('ɢᴀɢᴀʟ bang')
    }
}

handler.help = ['searchsoundcloud <musik>']
handler.tags = ['search']
handler.command = /^(searchsoundcloud|ssc)$/i
handler.limit = true

export default handler
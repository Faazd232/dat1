/*• Nama Fitur : tofitur
• Type : Plugin ESM
• Link Channel : https://whatsapp.com/channel/0029VbBt4432f3ENa8ULoM1J
• Author : Z7
• Note : untuk apikey pastikan udh array jngn string 
*/
import { GoogleGenerativeAI } from "@google/generative-ai";

let googleKeyIndex = 0;
function getGoogleKey() {
    const keys = global.googleAiApiKey;
    const key = keys[googleKeyIndex % keys.length];
    googleKeyIndex++;
    return key;
}

function getGenAI(key) {
    return new GoogleGenerativeAI(key);
}

function buildEnglishPrompt(sourceCode) {
    return `
You are an expert WhatsApp bot developer. Convert the provided code into a fully working ESM plugin for a WhatsApp bot.

Requirements:
- Wrap the code inside an async handler(m, { conn, args }).
- Add handler.command, handler.help, handler.tags, and handler.description.
- Use only ESM (import/export).
- DO NOT change logic or variable names unless required for ESM.
- ONLY return raw code. No markdown, no explanations.

Source Code:
${sourceCode}

Now return the final ESM plugin code only.
`;
}

const handler = async (m, { conn, args }) => {
    if (!global.googleAiApiKey || !Array.isArray(global.googleAiApiKey)) {
        return m.reply("API Key Google AI tidak ditemukan.");
    }

    const sourceCode = args.join(" ") || (m.quoted && m.quoted.text);
    if (!sourceCode) return m.reply("Silakan sertakan kode atau reply kode.");

    await m.reply("⏳ Mengonversi kode ke format ESM...");

    const keys = [...global.googleAiApiKey];
    let success = false;
    let lastError;
    let usedKeyIndex = null;

    for (let i = 0; i < keys.length; i++) {
        const key = getGoogleKey();
        try {
            const prompt = buildEnglishPrompt(sourceCode);
            const model = getGenAI(key).getGenerativeModel({ model: "gemini-2.5-pro" });

            const result = await model.generateContent(prompt);
            const response = await result.response;
            let textResult = response.text().trim();

            textResult = textResult.replace(/```+/g, "").trim();

            await conn.sendMessage(m.chat, { text: textResult }, { quoted: m });
            success = true;
            usedKeyIndex = i + 1;
            break; // berhasil, keluar loop
        } catch (err) {
            lastError = err;
            console.warn(`API Key ${i + 1} gagal, mencoba key berikutnya... (${err.message})`);
        }
    }

    if (success) {
        await conn.sendMessage(m.chat, { text: `✅ Konversi berhasil dengan API Key ke-${usedKeyIndex}` }, { quoted: m });
    } else {
        await conn.sendMessage(m.chat, { text: "❌ Semua API Key gagal: " + lastError?.message }, { quoted: m });
    }
};

handler.command = ["tofitur"];
handler.help = ["tofitur"];
handler.tags = ["ai"];
handler.owner = true;

export default handler;
/**
⧉ fitur : [upch]
⧉ creator : [Hanz] (modified)
**/

import fetch from 'node-fetch'

let handler = async (m, { conn, text, usedPrefix, command }) => {
    const idch = '120363287205109562@newsletter'
    const thumbUrl = 'https://files.catbox.moe/m44n7d.jpg'

    const q = m.quoted ? m.quoted : m
    const mime = q.mimetype || q.mediaType || ''

    if (!m.quoted && !text) {
    throw `Contoh penggunaan:
• ${usedPrefix + command} teks
• Reply gambar / video / audio lalu ketik ${usedPrefix + command}`
}

    let thumbnail = await fetch(thumbUrl)
        .then(res => res.buffer())
        .catch(() => null)

    await conn.sendMessage(m.chat, {
        react: { text: '😒', key: m.key }
    })

    // ======================
    // 📌 BASE CONTEXT INFO
    // ======================
    const contextInfo = {
        externalAdReply: {
            title: global.namabot,
            body: global.namaowner,
            thumbnail,
            mediaType: 1,
            renderLargerThumbnail: true,
            showAdAttribution: false
        }
    }

    // ======================
    // 🖼️ IMAGE
    // ======================
    if (/image/.test(mime)) {
        const media = await q.download()
        await conn.sendMessage(idch, {
            image: media,
            caption: text || '',
            contextInfo
        })
    }

    // ======================
    // 🎥 VIDEO
    // ======================
    else if (/video/.test(mime)) {
        const media = await q.download()
        await conn.sendMessage(idch, {
            video: media,
            caption: text || '',
            contextInfo
        })
    }

    // ======================
    // 🔊 AUDIO / OPUS
    // ======================
    else if (/audio/.test(mime)) {
        const media = await q.download()
        await conn.sendMessage(idch, {
            audio: media,
            mimetype: mime,
            ptt: true,
            contextInfo
        })
    }

    // ======================
    // 📝 TEXT ONLY
    // ======================
    else {
        await conn.sendMessage(idch, {
            text: text,
            contextInfo
        })
    }

    await conn.sendMessage(m.chat, {
        react: { text: '✅', key: m.key }
    })

    m.reply('✅ Berhasil dikirim ke channel')
}

handler.command = /^(upch)$/i
handler.help = ['upch <teks / reply media>']
handler.tags = ['owner']
handler.owner = true

export default handler
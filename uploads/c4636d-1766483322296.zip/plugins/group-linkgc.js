let handler = async (m, { conn, groupMetadata }) => {
let response = await conn.groupInviteCode(m.chat)
let us = `Sukses Mengambil Link Group!! 
Link : https://chat.whatsapp.com/${response}
Group : ${groupMetadata.subject}`
await conn.sendMessage(m.chat, {
            text: us,
            contextInfo: {
                mentionedJid: [m.sender],
                externalAdReply: {
                    title: `${namabot}`,
                    body: `${groupMetadata.subject}`,
                    thumbnailUrl: global.thum || '',
                    sourceUrl: `https://chat.whatsapp.com/${response}`,
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m })

            }
handler.tags = ["group"]
handler.help = ["linkgroup"]
handler.command = /^(linkgc|linkgroup|grouplink)/i
handler.admin = true
handler.group = true
handler.botAdmin = false
export default handler
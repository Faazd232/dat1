import axios from 'axios'

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) return m.reply(`ᴋɪʀɪᴍ ᴜʀʟ ᴛɪᴋᴛᴏᴋ ʏᴀɴɢ ɪɴɢɪɴ ᴋᴀᴍᴜ ᴅᴏᴡɴʟᴏᴀᴅ`)

    const url = args[0]
    
    await m.reply('sᴇᴅᴀɴɢ ᴍᴇɴᴅᴏᴡɴʟᴏᴀᴅ...')

    try {
        const { data } = await axios.get(`https://api.elrayyxml.web.id/api/downloader/tiktok?url=${encodeURIComponent(url)}`)

const endpoin = `https://api.elrayyxml.web.id/api/downloader/tiktok?url=${encodeURIComponent(url)}`
        if (!data?.status) {
        return m.reply('Error Jirr') 
        }
        if (!data?.result) {
        return m.reply(`Resultnya gak ada jir coba cek di ${endpoin}`) 
        }
const res = data.result
       if (Array.isArray(res.data)) {

      global.ttFoto = global.ttFoto || {}
      global.ttFoto[m.sender] = {
        index: 0,
        photos: res.data,
        meta: res
      }

      return kirimFotoSekarang(conn, m, m.sender)
    }
if (typeof res.data === 'string') {
      return conn.sendMessage(m.chat, {
        video: { url: res.data },
        caption: `*TIKTOK DOWNLOADER*
Judul : ${res.title}
Dibuat : ${res.taken_at}
Negara : ${res.region}
Durasi : ${res.duration}
ID : ${res.id}
*INFO MUSIK*
Judul : ${res.music_info.title}
Artis : ${res.music_info.author}
Album : ${res.music_info.album}
Durasi : ${res.music_info.duration}
*STATUS VIDEO*
View : ${res.stats.views}
Likes : ${res.stats.likes}
Comment : ${res.stats.comment}
Share : ${res.stats.share}
Download : ${res.stats.download}
*AUTHOR VIDEO*
Nama : ${res.author.nickname}
Nama Lengkap : ${res.author.fullname}`
      }, { quoted: m })
      await conn.sendMessage(m.chat, {
      audio: { url: res.music_info.url }, 
      mimetype: 'audio/mpeg' }, 
      { quoted: m }) 
    }
    
    } catch (e) {
        console.log(e)
        m.reply('Errorrrrrrrrr')
    }
}

handler.help = ['tiktok3 <url>']
handler.tags = ['download']
handler.command = /^(tiktok3|tt3)$/i
handler.limit = true

export default handler

async function kirimFotoSekarang(conn, m, sender) {
  const session = global.ttFoto[sender]
  if (!session) return m.reply('Session foto habis')

  const { index, photos, meta } = session

  const caption = `
*TIKTOK PHOTO*
(${index + 1}/${photos.length})

Judul : ${meta.title}
Dibuat : ${meta.taken_at}
Negara : ${meta.region}
Durasi : ${meta.duration}
ID : ${meta.id}
*INFO MUSIK*
Judul : ${meta.music_info.title}
Artis : ${meta.music_info.author}
Album : ${meta.music_info.album}
Durasi : ${meta.music_info.duration}
*STATUS VIDEO*
View : ${meta.stats.views}
Likes : ${meta.stats.likes}
Comment : ${meta.stats.comment}
Share : ${meta.stats.share}
Download : ${meta.stats.download}
*AUTHOR VIDEO*
Nama : ${meta.author.nickname}
Nama Lengkap : ${meta.author.fullname}

Ketik *.skip* untuk foto berikutnya
`.trim()

  await conn.sendMessage(
    m.chat,
    {
      image: { url: photos[index] },
      caption
    },
    { quoted: m }
  )
  await conn.sendMessage(m.chat, {
  audio: { url: meta.music_info.url }, 
  mimetype: 'audio/mpeg' },
  { quoted: m }) 
}
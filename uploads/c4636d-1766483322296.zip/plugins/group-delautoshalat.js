import fs from 'fs'

const dbPath = './database/idautoshalat.json'

let handler = async (m, { isAdmin, isOwner }) => {
  if (!m.isGroup) return m.reply('❌ Khusus grup')
  if (!(isAdmin || isOwner)) return m.reply('❌ Admin only')

  if (!fs.existsSync(dbPath))
    return m.reply('⚠️ Auto shalat belum pernah diaktifkan')

  let db = JSON.parse(fs.readFileSync(dbPath))

  if (!db[m.chat])
    return m.reply('⚠️ Auto shalat belum aktif di grup ini')

  delete db[m.chat]

  fs.writeFileSync(dbPath, JSON.stringify(db, null, 2))

  m.reply('✅ *Auto Shalat berhasil dinonaktifkan di grup ini*')
}

handler.command = ['delautoshalat']
handler.tags = ['group']
handler.help = ['delautoshalat']
handler.admin = true
handler.group = true

export default handler
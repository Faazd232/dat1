let a = async (m, { conn, text, usedPrefix, command }) => {
if (!text) return m.reply(`Dimana teksnya?\nContoh: ${usedPrefix + command} Nano BotID`)
    await conn.updateProfileStatus(text)
    m.reply(`Success in changing the bio of bot's number`)
    }
a.tags = ["owner"]
a.help = ["setbiobot <teks>"]
a.command = /^(setbiobot|setbotbio)$/i
a.owner = true

export default a
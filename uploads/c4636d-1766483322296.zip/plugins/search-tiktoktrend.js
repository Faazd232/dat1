import axios from 'axios'

let handler = async (m, { conn, args, usedPrefix, command }) => {
    await m.reply('sᴇᴅᴀɴɢ ᴍᴇɴᴄᴀʀɪ ᴠɪᴅᴇᴏ...')

    try {
        const { data } = await axios.get(`https://api.elrayyxml.web.id/api/search/tiktoktrend?id=id`)

const endpoin = `https://api.elrayyxml.web.id/api/search/tiktoktrend?id=id`
        if (!data?.status) {
        return m.reply('Error Jirr') 
        }
        if (!Array.isArray(data.result) || data.result.length === 0) {
        return m.reply(`Resultnya gak ada jir coba cek di ${endpoin}`) 
        }

        // simpan ke memory
    global.ttTrend = global.ttTrend || {}
    global.ttTrend[m.sender] = {
      index: 0,
      results: data.result
    }

    await kirimHasilTt(conn, m, m.sender)

    } catch (e) {
        console.log(e)
        m.reply('Errorrrrrrrrr')
    }
}

handler.help = ['tiktoktrend']
handler.tags = ['search']
handler.command = /^(tiktoktrend|ttrend)$/i
handler.limit = true

export default handler

async function kirimHasilTt(conn, m, sender) {
  const data = global.ttTrend[sender]
  const res = data.results[data.index]

  const caption = `
*TIKTOK SEARCH TREND* (${data.index + 1}/${data.results.length})

Judul : ${res.title}
Dibuat : ${res.taken_at}
Negara : ${res.region}
Durasi : ${res.duration}
ID : ${res.id}
*INFO MUSIK*
Judul : ${res.music_info.title}
Artis : ${res.music_info.author}
Album : ${res.music_info.album}
Durasi : ${res.music_info.duration}
*STATUS VIDEO*
View : ${res.stats.views}
Likes : ${res.stats.likes}
Comment : ${res.stats.comment}
Share : ${res.stats.share}
Download : ${res.stats.download}
*AUTHOR VIDEO*
Nama : ${res.author.nickname}
Nama Lengkap : ${res.author.fullname}

Ketik *.next* untuk video berikutnya
`.trim()

  await conn.sendMessage(
    m.chat,
    {
      video: { url: res.data },
      caption
    },
    { quoted: m }
  )
}
import fs from 'fs'
import path from 'path'

const pluginDir = './plugins'

let handler = async (m, { text, isOwner }) => {
  if (!isOwner) return m.reply('❌ Owner only')

  if (!text) {
    return m.reply(
      '⚠️ Contoh:\n.enatur hayam group-hayang'
    )
  }

  let [oldName, newName] = text.trim().split(/\s+/)
  if (!oldName || !newName)
    return m.reply('❌ Format salah\nContoh: .enatur hayam group-hayang')

  // 🔥 AUTO TAMBAH .js
  if (!oldName.endsWith('.js')) oldName += '.js'
  if (!newName.endsWith('.js')) newName += '.js'

  const oldPath = path.join(pluginDir, oldName)
  const newPath = path.join(pluginDir, newName)

  if (!fs.existsSync(oldPath))
    return m.reply(`❌ File *${oldName}* tidak ditemukan`)

  // ✅ CEK FILE BARU SUDAH ADA
  if (fs.existsSync(newPath))
    return m.reply(`❌ Gagal! File *${newName}* sudah ada, mohon ganti nama baru yang unik.`)

  try {
    fs.renameSync(oldPath, newPath)
    m.reply(
`✅ *PLUGIN BERHASIL DIUBAH*

📄 Dari : ${oldName}
📄 Ke   : ${newName}

♻️ Restart bot jika plugin belum terbaca`
    )
  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal rename plugin')
  }
}

handler.command = ['enatur']
handler.tags = ['owner']
handler.help = ['enatur <lama> <baru>']
handler.owner = true

export default handler
import { tmpdir } from 'os'
import { join } from 'path'
import { writeFileSync, readFileSync, unlinkSync } from 'fs'
import { exec } from 'child_process'

let handler = async (m, { conn, usedPrefix, command }) => {
    try {
        let q = m.quoted ? m.quoted : m
        let mime = q.mimetype || q.msg?.mimetype || ""

        if (!mime.includes("audio")) {
            return m.reply(
`⚠️ Kirim atau reply audio lalu ketik *${usedPrefix + command}*`
            )
        }

        let buffer = await q.download()

        let input = join(tmpdir(), Date.now() + '.mp3')
        let output = join(tmpdir(), Date.now() + '-ptt.ogg')

        writeFileSync(input, buffer)

        // Slow 0.95x + reverb echo ringan
        await new Promise((resolve, reject) => {
            exec(
                `ffmpeg -y -i "${input}" -af "atempo=0.95, aecho=0.6:0.7:50:0.2" -c:a libopus "${output}"`,
                (err) => err ? reject(err) : resolve()
            )
        })

        let pttBuffer = readFileSync(output)

        await conn.sendMessage(m.chat, {
            audio: pttBuffer,
            mimetype: 'audio/ogg; codecs=opus',
            ptt: true
        }, { quoted: m })

        unlinkSync(input)
        unlinkSync(output)

    } catch (e) {
        console.error(e)
        m.reply('❌ Gagal membuat efek slow + reverb')
    }
}

handler.help = ['slowreverb']
handler.tags = ['tools']
handler.command = /^slowreverb$/i
handler.limit = true

export default handler
import fs from 'fs'
import fetch from 'node-fetch'

const DB_PATH = './database/idautoshalat.json'

async function fetchJson(url) {
  const res = await fetch(url)
  if (!res.ok) throw new Error(`HTTP ${res.status}`)
  return res.json()
}

let handler = async (m, { text, isAdmin, isOwner }) => {
  if (!m.isGroup) return m.reply('❌ Fitur ini hanya untuk grup')
  if (!(isAdmin || isOwner)) return m.reply('❌ Admin grup only')

  if (!text)
    return m.reply('⚠️ Contoh:\n.addautoshalat bekasi')

  // 🔍 cari kota
  const data = await fetchJson(
    `https://cloudku.us.kg/api/murotal/search/kota?q=${encodeURIComponent(text)}`
  )

  if (!data?.result?.data?.length)
    return m.reply(`❌ Kota *${text}* tidak ditemukan`)

  // Prioritas KOTA
  const kota =
    data.result.data.find(v => v.lokasi.includes('KOTA')) ||
    data.result.data[0]

  // 📂 load DB
  let db = {}
  if (fs.existsSync(DB_PATH)) {
    db = JSON.parse(fs.readFileSync(DB_PATH))
  }

  // 💾 simpan
  db[m.chat] = {
    enabled: true,
    cityId: kota.id,
    cityName: kota.lokasi
  }

  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2))

  m.reply(
`✅ *AUTO SHALAT AKTIF*

📍 Kota : ${kota.lokasi}
🆔 ID   : ${kota.id}

🕌 Jadwal shalat akan dikirim otomatis setiap waktu masuk`
  )
}

handler.command = ['addautoshalat']
handler.tags = ['group']
handler.help = ['addautoshalat <nama kota>']
handler.admin = true
handler.group = true

export default handler
import axios from 'axios'

let handler = async (m, { conn, args, usedPrefix, command }) => {
    if (!args[0]) return m.reply(`ᴋɪʀɪᴍ ᴅᴇɴɢᴀɴ ᴋᴀᴛᴀ ʏᴀɴɢ ɪɴɢɪɴ ᴅɪ ᴄᴀʀɪ ᴀʀᴛɪɴʏᴀ`)

    const url = args.join(' ') 
    
    await m.reply('sᴇᴅᴀɴɢ ᴍᴇɴᴄᴀʀɪ...')

    try {
        const { data } = await axios.get(`https://api-faa.my.id/faa/kbbi?q=${encodeURIComponent(url)}`)

const endpoin = `https://api-faa.my.id/faa/kbbi?q=${encodeURIComponent(url)}`
        if (!data?.status) {
        return m.reply('Error Jirr') 
        }
        if (!data?.result) {
        return m.reply(`Resultnya gak ada jir coba cek di ${endpoin}`) 
        }
const res = data.result
let kbbi = `Arti Dari Kata ${url}
Artinya : ${res.keterangan}.`
       conn.sendMessage(m.chat, {
       text: kbbi, }, 
       { quoted: m }) 
       
       } catch (e) {
        console.error(e)
        m.reply('ɢᴀɢᴀʟ bang')
    }
}

handler.tags = ["tools"]
handler.help = ["kbbi <teks>"]
handler.command = /^(kbbi)$/i
handler.limit = true

export default handler
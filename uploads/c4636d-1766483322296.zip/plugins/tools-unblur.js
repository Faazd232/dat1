import axios from 'axios'
import crypto from 'crypto'
import { fileTypeFromBuffer } from 'file-type'

let handler = async (m, { conn }) => {
  const q = m.quoted || m
  const mime = q.mimetype || q.msg?.mimetype || ''

  if (!mime.startsWith('image/')) {
    return m.reply('Reply gambarnya')
  }

  await m.reply('🧠 Memproses unblur...')

  try {
    // 1. download image
    const buffer = await q.download()
    if (!buffer) throw 'Gagal download gambar'

    // 2. upload → github raw
    const { url } = await uploadToGithub(buffer)

    // 3. call unblur API
    const api = `https://api.elrayyxml.web.id/api/tools/unblur?url=${encodeURIComponent(url)}`
    const { data } = await axios.get(api, {
      responseType: 'arraybuffer'
    })

    // 4. kirim hasil
    await conn.sendMessage(
      m.chat,
      {
        image: Buffer.from(data),
        caption: '✨ Unblur selesai'
      },
      { quoted: m }
    )

  } catch (e) {
    console.error(e)
    m.reply('❌ Unblur gagal')
  }
}

handler.command = ['unblur']
handler.tags = ['tools']
handler.help = ['unblur (reply gambar)']
handler.limit = true

export default handler

const githubToken = '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' // ⚠️ jangan hardcode
const owner = 'Faazd232'
const branch = 'main'
let repos = ['dat1', 'dat2', 'dat3', 'dat4']

async function ensureRepoExists(repo) {
  try {
    await axios.get(
      `https://api.github.com/repos/${owner}/${repo}`,
      { headers: { Authorization: `Bearer ${githubToken}` } }
    )
  } catch (e) {
    if (e.response?.status === 404) {
      await axios.post(
        `https://api.github.com/user/repos`,
        { name: repo, private: false },
        { headers: { Authorization: `Bearer ${githubToken}` } }
      )
      if (!repos.includes(repo)) repos.push(repo)
    } else {
      throw e
    }
  }
}

function generateRepoName() {
  return `dat-${crypto.randomBytes(3).toString('hex')}`
}

async function uploadToGithub(buffer) {
  if (!Buffer.isBuffer(buffer)) {
    throw new Error('Input bukan buffer')
  }

  const detected = await fileTypeFromBuffer(buffer)
  const ext = detected?.ext || 'bin'
  const mime = detected?.mime || 'application/octet-stream'

  const code = crypto.randomBytes(3).toString('hex')
  const fileName = `${code}-${Date.now()}.${ext}`
  const filePath = `uploads/${fileName}`
  const base64 = buffer.toString('base64')

  let targetRepo = repos[Math.floor(Math.random() * repos.length)]

  try {
    await ensureRepoExists(targetRepo)
  } catch {
    targetRepo = generateRepoName()
    await ensureRepoExists(targetRepo)
  }

  await axios.put(
    `https://api.github.com/repos/${owner}/${targetRepo}/contents/${filePath}`,
    {
      message: `Upload ${fileName}`,
      content: base64,
      branch
    },
    {
      headers: {
        Authorization: `Bearer ${githubToken}`,
        'Content-Type': 'application/json'
      },
      maxBodyLength: Infinity
    }
  )

  return {
    url: `https://raw.githubusercontent.com/${owner}/${targetRepo}/${branch}/${filePath}`,
    fileName,
    ext,
    mime
  }
}
import axios from 'axios'

let handler = async (m, { conn, args }) => {
  try {
    // 1. Pastikan reply gambar
    let q = m.quoted ? m.quoted : m
    let mime = q.mimetype || q.mediaType || ''

    if (!/image/.test(mime)) {
      return m.reply('❌ Reply gambar dengan caption *editkulit*')
    }

    // 2. Download gambar
    let buffer = await q.download()
    let imageBase64 = buffer.toString('base64')

    // 3. Prompt (bisa custom)
    let prompt = args.join(' ') || 'ubah kulit karakter ini menjadi hitam'

    m.reply('⏳ Sedang memproses gambar...')

    // 4. Kirim ke API
    const res = await axios.post(
      'https://ai-studio.anisaofc.my.id/api/edit-image',
      {
        image: imageBase64,
        prompt
      },
      {
        headers: {
          'User-Agent': 'Mozilla/5.0',
          'Content-Type': 'application/json',
          'Origin': 'https://ai-studio.anisaofc.my.id',
          'Referer': 'https://ai-studio.anisaofc.my.id/'
        }
      }
    )

    if (!res.data?.success) {
      return m.reply('❌ Gagal mengedit gambar')
    }

    // 5. Kirim hasil
    await conn.sendMessage(
      m.chat,
      {
        image: { url: res.data.imageUrl },
        caption: `✅ *Berhasil!*`
      },
      { quoted: m }
    )

  } catch (e) {
    console.error(e)
    m.reply('❌ Terjadi error saat memproses gambar')
  }
}

handler.command = ['editkulit']
handler.tags = ['tools']
handler.help = ['editkulit <prompt>']

export default handler
